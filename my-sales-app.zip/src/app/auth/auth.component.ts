import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxNotificationMsgService, NgxNotificationDirection, NgxNotificationStatusMsg } from 'ngx-notification-msg';
import { AlertService } from '../_alert/alert.service';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {
  formGroup:FormGroup;

  initForm(){
    this.formGroup = new FormGroup({
      username: new FormControl('bikash', [Validators.required]),
      password: new FormControl('password', [Validators.required])
    })
  }

  login(){
    if(this.formGroup.valid){
      this.authService.login(this.formGroup.value).subscribe(res => {
        if(res.status === 'token'){
          localStorage.setItem('token', res.token)
          console.log(localStorage.getItem('token'))
          this.alert.success("Login Success", 'Welcome')
          this.router.navigateByUrl('dashboard');

        }else{
          this.alert.failure("incorrect username or password")
        }
      }) //authService Closed
    }

  }


  constructor(
    private authService:AuthService,
    private router: Router,
    // private ngxNotifierService: NgxNotifierService
    // private alert: AlertService
    private readonly alert: AlertService
    ) { }

  ngOnInit(): void {
    this.initForm();
  }

}
