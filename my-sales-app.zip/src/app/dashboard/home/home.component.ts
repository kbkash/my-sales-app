import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from '../../_alert/alert.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  user = localStorage.getItem('token')

  constructor(private router: Router){

  }

  signOut(){
    localStorage.clear()
    this.user=undefined;
    this.router.navigateByUrl('');
  }

  ngOnInit(): void {

  }

  // buttonClick(){
  //   this.alert.success("hello")
  // }

}
