import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { HomeComponent } from './home/home.component';
import { TestpageComponent } from './testpage/testpage.component';

const routes: Routes = [
  {
    path:"",
    component:DashboardComponent,
    children: [
        { path: 'test', component: TestpageComponent },
        { path: '', component: HomeComponent }
      ],
      
  },
  // {
  //   path: '',
  //   redirectTo: 'dashboard/home',
  //   pathMatch: 'full'
  // }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
