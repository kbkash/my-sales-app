import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  user = localStorage.getItem('token')

  constructor(private router: Router){

  }

  signOut(){
    alert(localStorage.getItem('token'))

    localStorage.clear()
    this.user=undefined;
    this.router.navigateByUrl('');
  }

  ngOnInit(): void {
  }

}
